from .cli import app

app(prog_name="yamlup")